Dummy file with invented examples.
