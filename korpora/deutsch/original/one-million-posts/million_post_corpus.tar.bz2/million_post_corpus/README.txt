Dummy-Datei mit erfundenen Beispielen im Format des One Million Posts Corpus.
Das Original: https://ofai.github.io/million-post-corpus/
