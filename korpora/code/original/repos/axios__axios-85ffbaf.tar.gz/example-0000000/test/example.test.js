const assert = require('assert');
const { readJson } = require('../lib/example');

describe('readJson', () => {
  it('parses a file', (done) => {
    readJson(__dirname + '/data.json', (err, value) => {
      assert.ifError(err);
      assert.strictEqual(value.name, 'example');
      done();
    });
  });
});
