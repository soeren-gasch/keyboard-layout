package org.example;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class UserServiceTest {

	@Test
	void findsUserByEmail() {
		UserService service = new UserService(new InMemoryUserRepository());
		assertTrue(service.findByEmail("a@example.org").isPresent());
	}
}
