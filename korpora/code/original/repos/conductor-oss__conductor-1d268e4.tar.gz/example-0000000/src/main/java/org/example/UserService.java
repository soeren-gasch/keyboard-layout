/*
 * Copyright (c) Example Project
 * Licensed under the MIT License. See LICENSE for details.
 */
package org.example;

import java.util.List;
import java.util.Optional;

public class UserService {

	private final UserRepository repository;

	public UserService(UserRepository repository) {
		this.repository = repository;
	}

	public Optional<User> findByEmail(String email) {
		return repository.findAll().stream()
				.filter(u -> u.getEmail().equalsIgnoreCase(email))
				.findFirst();
	}
}
