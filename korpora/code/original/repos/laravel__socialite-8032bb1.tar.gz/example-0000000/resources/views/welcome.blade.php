@extends('layouts.app')

@section('content')
    <h1>{{ $title }}</h1>
    @foreach ($posts as $post)
        <p>{{ $post->title }}</p>
    @endforeach
@endsection
