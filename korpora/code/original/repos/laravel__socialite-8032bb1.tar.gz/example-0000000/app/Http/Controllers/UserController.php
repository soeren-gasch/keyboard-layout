<?php
/*
 * Copyright (c) Example Project
 * Licensed under the MIT License. See LICENSE for details.
 */

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
	public function index(Request $request)
	{
		$users = User::query()
			->where('active', true)
			->orderBy('name')
			->paginate(15);

		return view('users.index', compact('users'));
	}
}
