<template>
  <main>
    <UserCard v-for="u in users" :key="u.id" :user="u" @select="open" />
  </main>
</template>

<script>
import UserCard from '../components/UserCard.vue'

export default {
  components: { UserCard },
  data() {
    return { users: [] }
  },
  async mounted() {
    const response = await fetch('/api/users')
    this.users = await response.json()
  },
}
</script>
