<template>
	<div class="user-card" @click="select">
		<h3>{{ user.name }}</h3>
		<p v-if="user.email">{{ user.email }}</p>
	</div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({ user: { type: Object, required: true } })
const emit = defineEmits(['select'])

const initials = computed(() => props.user.name.slice(0, 2).toUpperCase())

function select() {
	emit('select', props.user)
}
</script>

<style scoped>
.user-card {
	padding: 8px 12px;
}
</style>
