SELECT u.id, u.name, COUNT(p.id) AS posts
FROM users u
LEFT JOIN posts p ON p.user_id = u.id
WHERE u.created_at > '2024-01-01'
GROUP BY u.id, u.name
HAVING COUNT(p.id) > 3
ORDER BY posts DESC
LIMIT 10;

UPDATE users SET name = 'Anna' WHERE id = 1;
