-- Example schema
-- Licensed under the MIT License

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE,
    created_at TIMESTAMP DEFAULT now()
);

CREATE INDEX idx_users_email ON users (email);
